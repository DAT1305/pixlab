# PixLab Codex

Repo-local Codex plugin for driving PixLab from sprite-generation workflows.

## What it does

- gives Codex a dedicated PixLab spritesheet workflow skill
- opens PixLab directly on the spritesheet import tab
- pairs well with image generation prompts for producing sprite strips/sheets
- adds a repo marketplace entry so the plugin can appear in Codex plugin UI

## Use it

1. Install the repo-local plugin from `plugins/pixlab-codex`.
2. Start a new Codex thread.
3. Invoke the skill explicitly, for example:
   - `@pixlab-codex:pixlab-spritesheet-workbench generate a 4x4 jump spritesheet and prep a GIF preview`
4. Codex should generate the sheet, open PixLab, upload it, and use crop/preview controls.

## App-backed upgrade path

The plugin is usable now through its skill and browser workflow, but `.app.json`
is intentionally empty because local plugin app manifests point to registered
`asdk_app_*` ids rather than arbitrary URLs.

When you later register a ChatGPT/Codex app for PixLab, replace `.app.json`
with:

```json
{
  "apps": {
    "pixlab": {
      "id": "asdk_app_[your_id_here]"
    }
  }
}
```
