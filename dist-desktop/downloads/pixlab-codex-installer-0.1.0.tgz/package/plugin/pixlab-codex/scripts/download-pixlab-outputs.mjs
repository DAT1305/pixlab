#!/usr/bin/env node

import { mkdir, writeFile } from 'node:fs/promises';
import { basename, join, resolve } from 'node:path';

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to load manifest (${response.status}): ${url}`);
  }
  return response.json();
}

async function fetchBuffer(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download file (${response.status}): ${url}`);
  }
  const arrayBuffer = await response.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

async function main() {
  const [, , manifestUrl, outputDirArg = './pixlab-output'] = process.argv;
  if (!manifestUrl) {
    throw new Error('Usage: node download-pixlab-outputs.mjs <manifest-url> [output-dir]');
  }

  const outputDir = resolve(outputDirArg);
  await mkdir(outputDir, { recursive: true });

  const manifest = await fetchJson(manifestUrl);
  const animations = Array.isArray(manifest.animations) ? manifest.animations : [];
  if (animations.length === 0) {
    throw new Error('Manifest does not contain any animations.');
  }

  for (const animation of animations) {
    const gifUrl = String(animation.gifUrl || '');
    if (!gifUrl) continue;
    const fileName = String(animation.fileName || basename(gifUrl));
    const buffer = await fetchBuffer(gifUrl);
    await writeFile(join(outputDir, fileName), buffer);
  }

  await writeFile(
    join(outputDir, basename(new URL(manifestUrl).pathname)),
    Buffer.from(JSON.stringify(manifest, null, 2), 'utf8'),
  );

  process.stdout.write(
    JSON.stringify({
      outputDir,
      count: animations.length,
      files: animations.map((animation) => animation.fileName || basename(String(animation.gifUrl || ''))),
    }),
  );
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});
