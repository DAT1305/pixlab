#!/usr/bin/env node

import { basename } from 'node:path';
import { readFile } from 'node:fs/promises';

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

function assertPng(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.byteLength < PNG_SIGNATURE.byteLength) {
    throw new Error('Input file is not a valid PNG.');
  }
  if (!buffer.subarray(0, PNG_SIGNATURE.byteLength).equals(PNG_SIGNATURE)) {
    throw new Error('Only PNG files can be uploaded to PixLab staging.');
  }
}

async function main() {
  const [, , inputPath, serverBase = 'https://mafiler.com'] = process.argv;
  if (!inputPath) {
    throw new Error('Usage: node upload-local-spritesheet.mjs <png-path> [server-base-url]');
  }

  const buffer = await readFile(inputPath);
  assertPng(buffer);

  const uploadUrl = new URL('/mcp/upload', serverBase).toString();
  const response = await fetch(uploadUrl, {
    method: 'POST',
    headers: {
      'content-type': 'image/png',
      'x-file-name': basename(inputPath),
    },
    body: buffer,
  });

  const text = await response.text();
  if (!response.ok) {
    throw new Error(`Upload failed (${response.status}): ${text}`);
  }

  process.stdout.write(text);
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});
