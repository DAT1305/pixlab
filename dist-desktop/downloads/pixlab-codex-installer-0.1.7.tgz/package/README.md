# pixlab-codex-installer

Install the PixLab Codex plugin with one short command:

```bash
npx pixlab-codex-installer
```

Optional commands:

```bash
npx pixlab-codex-installer --upgrade
npx pixlab-codex-installer --uninstall
```

Optional target Codex home:

```bash
npx pixlab-codex-installer --codex-home /path/to/.codex
```

After install, restart Codex desktop and open the plugin picker.
