---
name: pixlab-spritesheet-workbench
description: Generate a pixel spritesheet or animation bundle and run it through PixLab MCP tools. Use when Codex should drive the PixLab pipeline from an image generation prompt.
---

# PixLab Spritesheet Workbench

Use this skill when the user wants Codex to:

- generate a spritesheet or animation bundle from a prompt
- send that spritesheet into PixLab
- let PixLab crop frames and remove the chroma-key background
- return final GIF output that Codex can render for the user
- use the shortest PixLab path that satisfies the requested output

## Mode selection

- For all MCP-driven PixLab processing, use `processingMode: "client"` by default.
- MCP/plugin flows must not use `processingMode: "server"`.
- If the user wants a finished GIF back in the thread, still start with the direct client path:
  `local PNG -> upload helper -> process_pixlab_spritesheet with processingMode: "client"`
- If the user wants one GIF per animation row, prefer:
  `local PNG -> upload helper -> export_pixlab_bundle_rows`
- Do not switch to `processingMode: "server"` later just to obtain a GIF URL.
- Do not probe unsupported inputs first. If the source is local-only, upload it first.

## URLs

- Production PixLab spritesheet entry:
  `https://mafiler.com/?tab=spritesheet-gif`
- Local dev entry when the project is running:
  `http://127.0.0.1:4173/?tab=spritesheet-gif`

Prefer the local URL when the user is actively editing this repo and the dev
server is already running. Otherwise use production.

## Workflow

1. If the user needs a new spritesheet, generate it first with the available image generation tool.
   Use a strict default prompt shape unless the user explicitly asks for a different layout:
   - `6 columns x N rows`
   - `6 frames per animation`
   - `each row is one separate animation`
   - `N` can be `1` to `6`
   - examples:
     - `6x1` = 1 animation
     - `6x2` = 2 animations
     - `6x3` = 3 animations
     - `6x6` = 6 animations
   - `equal-sized cells`
   - `no spacing or gutters`
   - `flat chroma key background`, preferably bright magenta
   - do not ask for a transparent background unless the user explicitly requests transparency
2. If the direct PixLab MCP tools are available, you must use them first.
3. If the spritesheet exists only as a local file path and you cannot pass a direct file object into the tool, use the bundled helper script at `../scripts/upload-local-spritesheet.mjs` to upload the PNG to PixLab staging, then pass the returned `imageUrl` into the processing tool.
4. Do not spin up ad-hoc localhost servers or temporary HTTP file servers just to bridge a local PNG into PixLab.
5. PixLab MCP does not accept raw local filesystem paths like `C:\...` or `/Users/...` as `imageUrl`.
   If the source image is local-only, you must upload it with `../scripts/upload-local-spritesheet.mjs` first.
   Do not try the direct MCP tool with a local path and then "discover" that it fails.
   Do not pass empty `file_id` values.
   Go straight to the upload helper, then call the MCP tool with the returned HTTPS URL.
6. When the user asks for a single final GIF in-thread, call the processing tool with:
   - `processingMode: "client"`
   - `backgroundRemovalMode: "alpha-matte"`
   - `anchorMode: "bottom-center"`
   - `columns: 6`
   - `rows: N` only as a bundle hint
7. In client mode, PixLab must use true auto-crop detection, automatic background cleanup, and `anchorMode: "bottom-center"`.
   This client path is the authoritative path for MCP/plugin use.
8. If the direct MCP tool is unavailable, stop and tell the user that the PixLab MCP surface did not load in this workspace or thread.
9. Only use the PixLab launcher / external app workflow when the user explicitly asks to open PixLab or inspect the workspace manually.
10. Prefer explicit sheet constraints in the prompt:
   - equal-sized cells
   - fixed `6 columns`
   - fixed row count that matches animation count
   - no spacing between cells
   - flat magenta chroma key background
   - pixel-art style, not painterly rendering
11. When the user asks for an animation bundle:
   - treat each row as a separate animation
   - keep each row to exactly `6` frames
   - keep character scale and baseline consistent across the whole bundle
   - generate a short name for each row animation
   - when the user wants usable outputs for Codex or the user directly, prefer `export_pixlab_bundle_rows`
   - pass semantic `rowNames` when available so the returned GIF URLs are already named correctly
   - if the app later exports rows as separate GIFs, those row names should be the intended output names
   - encode the row names into the spritesheet file name using this suffix pattern:
     `__rows-idle--run--attack`
   - use short kebab-case names only
   - example:
    `knight-bundle__rows-idle--run--attack--die.png`
   - for manual inspection, the PixLab client widget is the authoritative visual-processing path inside the app
   - but for agent-usable outputs, use `export_pixlab_bundle_rows` so Codex gets one GIF per row directly
   - after `export_pixlab_bundle_rows` returns, immediately download the returned row GIFs into the active workspace using the bundled helper script at `../scripts/download-pixlab-outputs.mjs`
   - do not leave bundle outputs only on the PixLab server
   - keep the semantic row names as the local file names
   - do not re-run the same bundle through `processingMode: "server"` just to force a preview GIF
   - do not collapse the whole bundle into one combined GIF unless the user explicitly asks for that
   - do not prefer ZIP when the user or agent needs to preview/use each animation directly
12. Save the generated sheet to the workspace only if you need it for the upload helper or the manual browser fallback.
13. Open PixLab at `?tab=spritesheet-gif` in the built-in browser only in the manual-inspection fallback.
14. Upload the generated spritesheet to PixLab.
15. Use PixLab controls to:
   - auto detect and crop when possible
   - inspect the frame order
   - preview the animation
   - adjust rows, columns, delay, and anchor when needed
16. Report back with the final GIF, not just a preview or a plan.

## Prompting guidance for image generation

- Ask for a spritesheet or animation bundle, not a single pose.
- State the exact grid. Default to `6 columns x N rows`.
- Always make each row exactly `6` frames.
- If bundle output is requested, explicitly say that each row is a different animation sequence.
- Infer a semantic row name for each animation row and keep that order stable.
- Ask for consistent character scale across frames .
- Ask for a flat chroma key background to make auto-crop easier , no grid lines , no borders ,no outlines between the cells.
- Avoid phrases like `transparent background` or `PNG transparency` unless the user explicitly wants that.
- If the user wants a game-ready result, prefer sharp pixel edges and no motion blur.

## What this skill can do immediately

- It can guide Codex to use image generation plus the direct PixLab MCP processing tool when the tool is available.
- In the default MCP flow, the tool stages the PNG and PixLab client mode performs the crop and background cleanup on the user machine.
- For manual inspection, the same client widget path remains the authoritative path.
- The default mental model is now `6 columns x N rows`, where each row is one animation.
- When a local PNG path is all that is available, it can use the bundled upload helper script to stage that file without relying on localhost workarounds.
- It can still fall back to the PixLab website when manual inspection is needed, but only when the user explicitly asks for that.
- It can use the project-local Run action to start the app inside Codex workflows.

## Final output rule

- After `process_pixlab_spritesheet` succeeds, you must show the final GIF to the user directly in the response when a real GIF URL exists.
- If the user asked for a finished GIF, do not switch away from client mode.
- Do not describe the result as a preview if a real GIF exists.
- Exception for bundle mode: do not switch to `server` just to manufacture a GIF URL. Keep the result in client mode and direct the user to the row-based ZIP export flow.

## Hard guardrail

- If the PixLab direct MCP tool surface is not present in the active thread, do not improvise with Playwright, browser automation, PIL, ImageMagick, or hand-written local processing pipelines.
- In that situation, stop and say the PixLab plugin MCP tools did not load correctly in this workspace/thread and ask the user to reload Codex or reconnect the plugin.

## Current limitation

This plugin now prefers direct MCP mapping through `.mcp.json`, which is the
reliable path for tool discovery across workspaces. The `.app.json` mapping can
remain as an optional companion for richer app surfaces after the ChatGPT app
is approved and published broadly enough for direct app attachment.
